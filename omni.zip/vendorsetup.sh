# Add lunch combos
add_lunch_combo omni_cactus-eng
add_lunch_combo omni_cactus-userdebug
